import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "CoastAI Automation | AI systems for growing businesses",
  description: "Mombasa-based AI automation agency and platform. Automate customer support, lead follow-up, bookings and business workflows.",
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body>{children}</body></html>;
}