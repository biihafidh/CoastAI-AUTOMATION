# Launch checklist

- [ ] Choose and register business name/domain after trademark/domain checks
- [ ] Review service descriptions, pricing and contact details
- [ ] Add privacy policy, terms and consent wording
- [ ] Configure Supabase Auth redirect URLs and database schema
- [ ] Implement secure organization onboarding and finish RLS policies
- [ ] Configure n8n webhook authentication and persistent lead storage
- [ ] Add API rate limiting and bot protection
- [ ] Add production monitoring, backups and error alerts
- [ ] Add OpenAI endpoint with budget/rate limits before advertising AI agents
- [ ] Complete WhatsApp Business verification and approved message flows
- [ ] Complete M-Pesa/Safaricom business onboarding before payment integration
- [ ] Add subscription billing and verify provider webhooks before charging users
- [ ] Test mobile layout, keyboard navigation and screen readers
- [ ] Run `npm run build` and resolve all build errors
- [ ] Configure production environment variables and custom domain
- [ ] Test login, tenant isolation, webhook failures and data deletion
