-- Apply in Supabase SQL editor. Review before production.
create extension if not exists pgcrypto;
create table if not exists public.organizations (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 created_at timestamptz not null default now()
);
create table if not exists public.organization_members (
 organization_id uuid not null references public.organizations(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null default 'member' check (role in ('owner','admin','member')),
 created_at timestamptz not null default now(),
 primary key (organization_id,user_id)
);
create table if not exists public.leads (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references public.organizations(id) on delete cascade,
 name text not null,
 email text not null,
 phone text,
 business_type text,
 channel text,
 pain_points text[] not null default '{}',
 source text not null default 'website',
 status text not null default 'new' check(status in ('new','contacted','qualified','won','lost')),
 created_at timestamptz not null default now()
);
create table if not exists public.automations (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references public.organizations(id) on delete cascade,
 name text not null,
 description text,
 status text not null default 'draft' check(status in ('draft','active','paused','error')),
 config jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);
create table if not exists public.automation_runs (
 id uuid primary key default gen_random_uuid(),
 automation_id uuid not null references public.automations(id) on delete cascade,
 status text not null check(status in ('queued','running','succeeded','failed','needs_review')),
 started_at timestamptz,
 finished_at timestamptz,
 error_code text,
 created_at timestamptz not null default now()
);
create table if not exists public.integrations (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references public.organizations(id) on delete cascade,
 provider text not null,
 display_name text not null,
 status text not null default 'not_connected',
 -- Store secrets in a dedicated encrypted server-side vault, never in this JSON field.
 public_config jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);
alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.leads enable row level security;
alter table public.automations enable row level security;
alter table public.automation_runs enable row level security;
alter table public.integrations enable row level security;
create policy "members can view their organizations" on public.organizations for select using (
 exists(select 1 from public.organization_members m where m.organization_id=id and m.user_id=auth.uid())
);
create policy "members can view membership" on public.organization_members for select using (user_id=auth.uid());
create policy "members can read leads" on public.leads for select using (
 exists(select 1 from public.organization_members m where m.organization_id=leads.organization_id and m.user_id=auth.uid())
);
create policy "members can add leads" on public.leads for insert with check (
 exists(select 1 from public.organization_members m where m.organization_id=leads.organization_id and m.user_id=auth.uid())
);
create policy "members can read automations" on public.automations for select using (
 exists(select 1 from public.organization_members m where m.organization_id=automations.organization_id and m.user_id=auth.uid())
);
create policy "admins can manage automations" on public.automations for all using (
 exists(select 1 from public.organization_members m where m.organization_id=automations.organization_id and m.user_id=auth.uid() and m.role in ('owner','admin'))
) with check (
 exists(select 1 from public.organization_members m where m.organization_id=automations.organization_id and m.user_id=auth.uid() and m.role in ('owner','admin'))
);
create policy "members can read runs" on public.automation_runs for select using (
 exists(select 1 from public.automations a join public.organization_members m on m.organization_id=a.organization_id where a.id=automation_id and m.user_id=auth.uid())
);
create policy "admins can view integrations" on public.integrations for select using (
 exists(select 1 from public.organization_members m where m.organization_id=integrations.organization_id and m.user_id=auth.uid() and m.role in ('owner','admin'))
);
