# CoastAI Automation — full-stack starter

A Next.js starter for a Mombasa-based AI automation agency plus a future subscription platform.

## Included
- Marketing homepage and service/pricing sections
- Interactive automation audit and API route
- Optional n8n webhook forwarding for audit leads
- Supabase email magic-link login and callback
- Client workspace pages: overview, automations, agents, leads, conversations, analytics, integrations, billing
- Supabase starter schema with organization membership and basic RLS
- KES-first pricing copy and Kenya/East Africa positioning

## Important status
This is a starter project, **not a production-ready or deployed SaaS**. The dashboard is mostly illustrative UI. Audit submissions are forwarded only when `N8N_WEBHOOK_URL` is configured; otherwise they are not persisted. Login needs Supabase setup. WhatsApp, M-Pesa, OpenAI agents, subscription billing, production CRM persistence and real analytics are not yet activated. Never claim the example metrics are real.

## Requirements
- Node.js 20+
- Supabase project (for login/database)
- Optional n8n instance/webhook
- Optional OpenAI API account for a later AI endpoint

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env.local`.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open `http://localhost:3000`.

The site runs without Supabase credentials, but login will show a configuration message.

## Configure Supabase
1. Create a Supabase project.
2. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` to `.env.local`.
3. In Supabase Auth, enable email OTP/magic links and add your local and production redirect URLs.
4. Run `supabase/schema.sql` in the SQL editor.
5. Before inviting customers, implement organization creation/onboarding, membership assignment, complete RLS policies, server-side authorization and tests. Do not use a service-role key in browser code.

## Configure n8n lead forwarding (optional)
Set `N8N_WEBHOOK_URL` to an HTTPS webhook you control. The audit endpoint will POST a validated lead payload. Secure the webhook with a secret or gateway, add rate limiting/spam protection, and configure retention/consent before collecting real leads.

## Recommended next implementation steps
1. Add database persistence for audit leads with server-side Supabase client and strict RLS.
2. Add server-side organization-aware access checks for every dashboard route and API.
3. Add OpenAI-backed assistant endpoint with rate limits, usage limits, safety checks and prompt-injection defenses.
4. Build a workflow execution service with run logs, retries, idempotency, approvals and alerting.
5. Add WhatsApp Cloud API webhooks and opt-in compliant message templates.
6. Add Safaricom Daraja integration only after business onboarding and credentials; verify callbacks and reconcile transactions server-side.
7. Add a subscription provider, webhook signature verification, invoices and entitlements.
8. Add privacy notice, terms, cookie/analytics controls, data retention/deletion and incident response.
9. Add tests, accessibility checks, backups, monitoring and deployment review.

## Pricing
Displayed KES prices are suggested starting points for your own business offer, not verified market averages. Confirm scope and third-party fees in a written quote.

## Deployment
Deploy to a Next.js-compatible host such as Vercel. Configure environment variables in the host dashboard, add production redirect URLs to Supabase, review headers/rate limits and run a production build before launching.
