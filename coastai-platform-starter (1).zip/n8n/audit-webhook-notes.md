# Optional n8n lead intake workflow

The app POSTs a validated JSON payload to `N8N_WEBHOOK_URL` when configured.

Suggested nodes:
1. Webhook (POST; HTTPS endpoint; authentication via a gateway or secret header added to the app).
2. Validate required fields and reject unexpected payloads.
3. Create a lead in your approved CRM/Supabase table.
4. Send an internal notification to your sales inbox.
5. Optionally draft a reply for human review.
6. Return a success response and log execution status.

Before production: add rate limits, spam protection, consent/retention rules, alerting, retry strategy, idempotency, and secure webhook authentication. Do not send unsolicited WhatsApp marketing messages. Use approved opt-in and template requirements.
